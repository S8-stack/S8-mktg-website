

import {S8Object} from "/S8-api/S8Object.js";


export class NeObject extends S8Object {




    constructor() {
        super();
    }


}