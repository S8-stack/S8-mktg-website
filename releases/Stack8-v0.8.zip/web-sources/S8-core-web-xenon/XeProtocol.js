



export const XENON_Keywords = {


  
    BOOT : 0x32,
      
      
    /* <func> */
    RUN_FUNC : 0x64,

    /* <func> */
    
  

};

