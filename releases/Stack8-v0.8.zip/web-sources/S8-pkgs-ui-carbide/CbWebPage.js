import { S8WebPage } from "/S8-api/S8WebPage.js";



export class CbWebPage extends S8WebPage {


    CSS_import(){
        
    }

    
}