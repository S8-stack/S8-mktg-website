


export class NeView {

    constructor(index){
        this.index = index;
    }


}