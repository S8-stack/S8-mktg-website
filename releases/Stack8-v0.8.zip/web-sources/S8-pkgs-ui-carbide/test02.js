

import { BohrTestObject } from "bohr/BohrTestObject.js";




const toto = new BohrTestObject();