
function parse(buffer){


	byte -> root header to detect shifts (fail safe)
	byte[2] -> give type of object Uint16
	byte[2] -> give index of object
	fixed number of bytes for the fields. All fields values must be defined
	Most field require pointer.
	switch on fieldbyte:
		

	
}
