
import { InboardMessage, VALIDATE_MODE, WARNING_MODE, ERROR_MODE } from "/S8-pkgs-people/InboardMessage.js";



/**
 * 
 */
export class InboardMessageSlot {



}