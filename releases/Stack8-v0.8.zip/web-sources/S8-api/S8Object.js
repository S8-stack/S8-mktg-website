
import { S8Vertex } from "./S8Vertex.js";



export class S8Object {


    /**
     * Automatically assigned by NeObjectTypeHandler
     * 
     * @type {S8Vertex}
     */
    S8_vertex;


    constructor() {
    }


}