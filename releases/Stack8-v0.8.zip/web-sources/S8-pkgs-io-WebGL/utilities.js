

/*
 * Utilities
 */

function rgb(r, g, b){
	return [r, g, b, 1.0];
};

function rgba(r, g, b, a){
	return [r, g, b, a];
};
