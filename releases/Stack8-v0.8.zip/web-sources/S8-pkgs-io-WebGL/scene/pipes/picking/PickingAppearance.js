
import { SWGL_Appearance } from "../SWGL_Appearance.js";






/**
 * CAD_Engine
 * 
 */
export class PickingAppearance extends SWGL_Appearance {


	/**
	 * 
	 */
	constructor() {
		super();
	}

	/**
	 * 
	 */
	S8_render() {
	}


	S8_dispose() {
	}

}


