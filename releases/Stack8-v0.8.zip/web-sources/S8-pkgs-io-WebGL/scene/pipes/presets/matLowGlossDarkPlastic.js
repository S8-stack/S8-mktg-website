

// definitions
style.initialize = function(){
	this.programId = "mat01";
	this.ambient = 	[0.19225, 0.19225, 0.19225, 0.0];
	this.diffuse = 	[0.2754, 0.2754, 0.20754, 0.0];
	this.specular = [0.28273, 0.28273, 0.28273, 0.0];
	this.shininess = 20;
}


// dispose callback function
style.dispose = function(){
};