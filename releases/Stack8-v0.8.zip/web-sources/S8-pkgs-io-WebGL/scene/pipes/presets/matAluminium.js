

// definitions
style.initialize = function(){
	this.programId = "mat01";
	
	
	this.ambient = 	[0.19225, 0.19225, 0.19225, 0.0];
	this.diffuse = 	[0.50754, 0.50754, 0.50754, 0.0];
	this.specular = [0.508273, 0.508273, 0.508273, 0.0];
	this.shininess = 51.2;
	
}


// dispose callback function
style.dispose = function(){
};