



style.initialize = function(){
	this.programId = "color";
};


style.dispose = function(){
};