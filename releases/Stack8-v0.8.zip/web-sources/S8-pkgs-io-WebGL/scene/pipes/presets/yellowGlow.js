


style.initialize = function(){
	this.programId = "glow";
};


style.dispose = function(){
};