/**
 * 
 */

// definitions
style.initialize = function(){
	this.programId = "color2";
	this.color = 	[0.2, 0.2, 0.2, 0.0];
}


// dispose callback function
style.dispose = function(){
};