

// definitions
style.initialize = function(){
	this.programId = "color2";
	this.color = 	[1.0, 0.0, 0.0, 1.0];
};


// dispose callback function
style.dispose = function(){
};