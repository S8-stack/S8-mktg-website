

// definitions
style.initialize = function(){
	this.programId = "color2";
	this.color = 	[0.3, 0.3, 0.3, 1.0];
}


// dispose callback function
style.dispose = function(){
};