

// definitions
style.initialize = function(){
	this.programId = "standard";
}

// dispose callback function
style.dispose = function(){
};