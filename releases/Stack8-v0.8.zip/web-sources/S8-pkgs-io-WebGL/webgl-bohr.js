

/**
 * 
 */
let WEBGL_BOHR_PREFIX = 0xa0000;